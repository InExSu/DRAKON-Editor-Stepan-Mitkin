
NAME* // Returns ownership. Can be null.
NAME_Clone(
	const NAME* old // Can be null.
);

